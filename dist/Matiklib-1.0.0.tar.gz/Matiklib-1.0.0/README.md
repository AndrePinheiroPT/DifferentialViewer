# Matik
Do you like work with math? Check out this library which can help you 
with some math intuition, apresetation of math concepts and create interactive graphs as 
you want!

WIP
